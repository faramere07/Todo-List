<div class="container">
	@yield('content')
</div>